<?php 
// $cars = array("Volvo", "BMW", "Toyota");

// echo $cars[0];


$ab = date('Y-m-d H:i:s', time());
echo $ab;

 ?>