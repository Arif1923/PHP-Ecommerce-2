<?php 
session_start();

echo $_SESSION['login_user'];

 ?>