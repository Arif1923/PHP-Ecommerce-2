<!DOCTYPE html>
<html>
	<title></title>
	<body>

	<form action="registration_submit.php" method="post">

		Email: <input type="text" name="email" required><br/>
		password: <input type="password" name="password" required><br/>
		Name: <input type="text" name="name" required><br/>

		<input type="submit" value="Submit" name="submit">

	</form>

	</body>

</html>