<!DOCTYPE html>
<html>
<body>

<form action="upload_submit.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="myfile" id="myfile">
    <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>